package com.mycompany.sampleproject;

import java.util.ArrayList;

public class Print extends Processing_elements {

    //constructor
    public Print(ArrayList<String> inputValue, ArrayList<Processing_elements> pastEntries) {
        //if there's no entries use past entries

    }

    //define these functions
    public void opertaions(){

    };
    public void outputs() {
    };
}
