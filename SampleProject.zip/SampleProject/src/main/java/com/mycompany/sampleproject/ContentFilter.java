package com.mycompany.sampleproject;

import java.util.ArrayList;

public class ContentFilter extends Processing_elements {

    //constructor
    public ContentFilter(ArrayList<String> inputValue, ArrayList<Processing_elements> pastEntries) {
        //if there's no entries use past entries

    }

    //define these functions
    public void opertaions(){

    };
    public void outputs() {
    };
}